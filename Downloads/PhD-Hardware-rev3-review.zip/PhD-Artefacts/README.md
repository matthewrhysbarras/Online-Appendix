# PhD hardware review package

Accompanies Matthew Rhys Barras's University of Hull PhD thesis, *Toward Mobile Neuroimaging: Design and Implementation of a Real-Time Multi-Modal EEG/fNIRS System*.

This is a component download from the local release candidate. Read [Hardware/README.md](Hardware/README.md), [PROVENANCE.md](PROVENANCE.md), [LICENSING.md](LICENSING.md) and [REVIEW.md](REVIEW.md). Prepared for restricted online reviewer access, separate from the thesis itself.
