# PhD firmware review package

Accompanies Matthew Rhys Barras's University of Hull PhD thesis, *Toward Mobile Neuroimaging: Design and Implementation of a Real-Time Multi-Modal EEG/fNIRS System*.

Component download from the Online Appendix. Read [Firmware/README.md](Firmware/README.md), [PROVENANCE.md](PROVENANCE.md), [LICENSING.md](LICENSING.md) and [REVIEW.md](REVIEW.md). Supplied for private reviewer access.
